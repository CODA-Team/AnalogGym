# MIPS CPU example in xschem
